
import React, { useState } from 'react';
import { Language } from '../types';

interface Props {
  language: Language;
}

const HowToReadPanel: React.FC<Props> = ({ language }) => {
  const [isOpen, setIsOpen] = useState(false);

  const t = {
    btn: language === 'ta' ? 'இந்த பகுப்பாய்வை எவ்வாறு படிப்பது' : 'How to Read This Analysis',
    scope: language === 'ta' ? 'பகுப்பாய்வு நோக்கம்' : 'Analysis Scope',
    scopeText: language === 'ta' 
      ? 'இந்த அமைப்பு கட்டமைப்பு ஆணை தோல்விகளை அடையாளம் காட்டுகிறது - அங்கு துறை ரீதியான விதிகள் மோதுகின்றன - செயல்பாட்டு தாமதங்கள் அல்ல.'
      : 'This system identifies structural mandate failures—where departmental codes conflict—not operational labor delays.',
    metrics: language === 'ta' ? 'முக்கிய அளவீடுகள்' : 'Key Metrics',
    handoffs: language === 'ta' ? 'ஒப்படைப்புகள்' : 'Handoffs',
    decay: language === 'ta' ? 'சிதைவு' : 'Decay',
    vacuum: language === 'ta' ? 'வெற்றிடம்' : 'Vacuum',
    handoffsText: language === 'ta' ? 'நிறுவனங்களுக்கு இடையே பணி மாற்றங்கள்.' : 'Task transfers between entities.',
    decayText: language === 'ta' ? 'காலப்போக்கில் பொறுப்புக்கூறல் அரிப்பு.' : 'Erosion of accountability over time.',
    vacuumText: language === 'ta' ? 'ஒரு வகைக்கு நிலையான உரிமை இல்லாத நிலை.' : 'Zero consistent ownership of a category.',
    logic: language === 'ta' ? 'தர்க்க ஓட்டம்' : 'Logic Flow',
    logicText: language === 'ta' 
      ? 'கொள்கை பரிந்துரைக்காக அதிகார வரம்பு முட்டுக்கட்டைகளை வெளிப்படுத்த மாதிரிகள் கட்டமைப்பு விளக்கமாக மொழிபெயர்க்கப்படுகின்றன.'
      : 'Patterns are translated into a Structural Interpretation to expose jurisdictional deadlocks for policy recommendation.'
  };

  return (
    <div className="mb-8 animate-in fade-in duration-700">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 px-6 py-3 bg-[#F4F3EE] border border-[#9C7A3C]/20 rounded-2xl hover:bg-white transition-all group"
      >
        <i className={`fas ${isOpen ? 'fa-chevron-up' : 'fa-info-circle'} text-[#9C7A3C] text-xs`}></i>
        <span className="text-[10px] font-black text-[#9C7A3C] uppercase tracking-[0.2em]">{t.btn}</span>
      </button>

      {isOpen && (
        <div className="mt-4 p-8 bg-white border border-[#9C7A3C]/10 rounded-[2.5rem] shadow-sm animate-in slide-in-from-top-4 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="space-y-3">
              <h5 className="text-[9px] font-black text-[#5A4628] uppercase tracking-widest border-b border-[#F4F3EE] pb-2">{t.scope}</h5>
              <p className="text-[10px] font-bold text-[#6A6A6A] leading-relaxed uppercase tracking-tight">
                {t.scopeText}
              </p>
            </div>
            <div className="space-y-3">
              <h5 className="text-[9px] font-black text-[#5A4628] uppercase tracking-widest border-b border-[#F4F3EE] pb-2">{t.metrics}</h5>
              <p className="text-[10px] font-bold text-[#6A6A6A] leading-relaxed uppercase tracking-tight">
                <span className="text-[#1E1E1E]">{t.handoffs}:</span> {t.handoffsText} <br/>
                <span className="text-[#1E1E1E]">{t.decay}:</span> {t.decayText} <br/>
                <span className="text-[#1E1E1E]">{t.vacuum}:</span> {t.vacuumText}
              </p>
            </div>
            <div className="space-y-3">
              <h5 className="text-[9px] font-black text-[#5A4628] uppercase tracking-widest border-b border-[#F4F3EE] pb-2">{t.logic}</h5>
              <p className="text-[10px] font-bold text-[#6A6A6A] leading-relaxed uppercase tracking-tight">
                {t.logicText}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HowToReadPanel;
